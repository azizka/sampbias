is.sampbias <- function(object, class2){
  inherits(object, "sampbias")}
